// Ponte estaiada - simulacao de tensoes com interface grafica (raylib)
// 4 pilares (Viga 01..04), 3 sensores por pilar (S1 topo, S2 meio, S3 base)
// Limites dos sensores: minimo 108, maximo 831
// Modo manual: clique num sensor, digite o valor e aperte ENTER
// Modo carro : escolha massa e velocidade e aperte Iniciar

#include "raylib.h"
#include <string>
#include <sstream>
#include <cmath>
using namespace std;

int main() {
    // ---------- Constantes do sistema ----------
    const int LARGURA_TELA = 1150, ALTURA_TELA = 680;
    const float LIM_MIN = 108.0f, LIM_MAX = 831.0f;
    const float PONTE_MIN = 60.0f, PONTE_MAX = 600.0f;
    const int NP = 4, NS = 3;
    const float TENSAO_BASE = 200.0f;
    const float CARGA_POR_TON = 15.0f;
    const float FATOR[NS] = {0.90f, 1.00f, 1.10f};   // S1 topo, S2 meio, S3 base

    // ---------- Area de desenho da ponte ----------
    const float PX0 = 90.0f, PX1 = 790.0f;            // primeiro e ultimo pilar (pixels)
    const float Y_TOPO = 130.0f, Y_DECK = 230.0f, Y_CHAO = 440.0f;
    const float Y_SENSOR[NS] = {285.0f, 340.0f, 395.0f};
    const float PAINEL_X = 860.0f;

    InitWindow(LARGURA_TELA, ALTURA_TELA, "Ponte Estaiada - Simulacao de Tensoes");
    SetExitKey(KEY_NULL);   // ESC nao fecha a janela (usamos ESC para cancelar a digitacao)
    SetTargetFPS(60);

    // ---------- Estado do programa ----------
    float comprimento = 300.0f;
    int modo = 0;                         // 0 = manual, 1 = carro
    float manual[NP][NS];
    float tensao[NP][NS];
    float pico[NP][NS];
    float influencia[NP];
    for (int p = 0; p < NP; p++) {
        influencia[p] = 0;
        for (int s = 0; s < NS; s++) {
            manual[p][s] = 300.0f;
            tensao[p][s] = 300.0f;
            pico[p][s] = 0;
        }
    }

    int selP = -1, selS = -1;             // sensor selecionado no modo manual
    string entrada, msgErro;

    float massa = 12000.0f, velocidade = 60.0f;
    float posCarro = 0.0f, tempoSim = 0.0f;
    bool rodando = false, terminou = false;
    const int ESCALAS[3] = {1, 5, 20};
    const char* ROT_ESCALA[3] = {"x1", "x5", "x20"};
    int idxEscala = 1;

    while (!WindowShouldClose()) {
        float dt = GetFrameTime();
        Vector2 mouse = GetMousePosition();
        bool clique = IsMouseButtonPressed(MOUSE_BUTTON_LEFT);

        // ---------- Botoes ----------
        Rectangle bManual   = {20, 20, 150, 36};
        Rectangle bCarro    = {180, 20, 150, 36};
        Rectangle bLmenos   = {360, 20, 36, 36};
        Rectangle bLmais    = {600, 20, 36, 36};
        Rectangle bMmenos   = {20, 560, 36, 32};
        Rectangle bMmais    = {230, 560, 36, 32};
        Rectangle bVmenos   = {290, 560, 36, 32};
        Rectangle bVmais    = {480, 560, 36, 32};
        Rectangle bIniciar  = {540, 560, 110, 32};
        Rectangle bReinicia = {660, 560, 110, 32};
        Rectangle bEscala   = {780, 560, 60, 32};

        if (clique && CheckCollisionPointRec(mouse, bManual)) modo = 0;
        if (clique && CheckCollisionPointRec(mouse, bCarro)) { modo = 1; selP = -1; entrada.clear(); }

        bool mudouComprimento = false;
        if (clique && CheckCollisionPointRec(mouse, bLmenos) && comprimento > PONTE_MIN) { comprimento -= 10; mudouComprimento = true; }
        if (clique && CheckCollisionPointRec(mouse, bLmais)  && comprimento < PONTE_MAX) { comprimento += 10; mudouComprimento = true; }
        if (mudouComprimento) {
            posCarro = 0; tempoSim = 0; rodando = false; terminou = false;
            for (int p = 0; p < NP; p++) for (int s = 0; s < NS; s++) pico[p][s] = 0;
        }

        float vao = comprimento / (NP - 1);               // S
        float escalaPx = (PX1 - PX0) / comprimento;       // pixels por metro

        // ---------- MODO MANUAL ----------
        if (modo == 0) {
            if (clique) {
                for (int p = 0; p < NP; p++)
                    for (int s = 0; s < NS; s++) {
                        Vector2 centro = {PX0 + p * vao * escalaPx, Y_SENSOR[s]};
                        if (CheckCollisionPointCircle(mouse, centro, 12)) {
                            selP = p; selS = s; entrada.clear(); msgErro.clear();
                        }
                    }
            }
            if (selP >= 0) {
                int c = GetCharPressed();
                while (c > 0) {
                    if (((c >= '0' && c <= '9') || c == '.') && entrada.size() < 7) entrada += (char)c;
                    c = GetCharPressed();
                }
                if (IsKeyPressed(KEY_BACKSPACE) && !entrada.empty()) entrada.pop_back();
                if (IsKeyPressed(KEY_UP)) manual[selP][selS] += 10;
                if (IsKeyPressed(KEY_DOWN)) manual[selP][selS] = fmaxf(0, manual[selP][selS] - 10);
                if (IsKeyPressed(KEY_ESCAPE)) { selP = -1; entrada.clear(); msgErro.clear(); }
            }
            if (selP >= 0 && (IsKeyPressed(KEY_ENTER) || IsKeyPressed(KEY_KP_ENTER))) {
                stringstream ss(entrada); float v; char sobra;
                if (ss >> v && !(ss >> sobra)) {
                    manual[selP][selS] = v;
                    msgErro.clear();
                    entrada.clear();
                    // avanca automaticamente para o proximo sensor
                    selS++;
                    if (selS == NS) { selS = 0; selP++; }
                    if (selP == NP) selP = -1;
                } else {
                    msgErro = "Valor invalido";
                }
            }
            for (int p = 0; p < NP; p++) {
                influencia[p] = 0;
                for (int s = 0; s < NS; s++) tensao[p][s] = manual[p][s];
            }
        }

        // ---------- MODO CARRO ----------
        else {
            if (clique && CheckCollisionPointRec(mouse, bMmenos) && massa > 500)   massa -= 500;
            if (clique && CheckCollisionPointRec(mouse, bMmais)  && massa < 60000) massa += 500;
            if (clique && CheckCollisionPointRec(mouse, bVmenos) && velocidade > 10)  velocidade -= 5;
            if (clique && CheckCollisionPointRec(mouse, bVmais)  && velocidade < 120) velocidade += 5;
            if (clique && CheckCollisionPointRec(mouse, bEscala)) idxEscala = (idxEscala + 1) % 3;

            bool reiniciar = clique && CheckCollisionPointRec(mouse, bReinicia);
            if (clique && CheckCollisionPointRec(mouse, bIniciar)) {
                if (terminou) reiniciar = true;
                rodando = !rodando;
            }
            if (reiniciar) {
                posCarro = 0; tempoSim = 0; terminou = false;
                if (CheckCollisionPointRec(mouse, bReinicia)) rodando = false;
                for (int p = 0; p < NP; p++) for (int s = 0; s < NS; s++) pico[p][s] = 0;
            }
            if (IsKeyPressed(KEY_SPACE)) rodando = !rodando;

            if (rodando) {
                posCarro += velocidade / 3.6f * dt * ESCALAS[idxEscala];
                tempoSim += dt * ESCALAS[idxEscala];
                if (posCarro >= comprimento) { posCarro = comprimento; rodando = false; terminou = true; }
            }

            bool naPonte = !terminou && (rodando || posCarro > 0);
            for (int p = 0; p < NP; p++) {
                float distancia = fabsf(posCarro - p * vao);
                influencia[p] = (naPonte && distancia < vao) ? 1.0f - distancia / vao : 0.0f;
                for (int s = 0; s < NS; s++) {
                    tensao[p][s] = (TENSAO_BASE + (massa / 1000.0f) * CARGA_POR_TON * influencia[p]) * FATOR[s];
                    if (naPonte && tensao[p][s] > pico[p][s]) pico[p][s] = tensao[p][s];
                }
            }
        }

        // ---------- Situacao geral ----------
        int pilaresAlerta = 0;
        for (int p = 0; p < NP; p++) {
            bool fora = false;
            for (int s = 0; s < NS; s++)
                if (tensao[p][s] < LIM_MIN || tensao[p][s] > LIM_MAX) fora = true;
            if (fora) pilaresAlerta++;
        }

        // =================== DESENHO ===================
        BeginDrawing();
        ClearBackground(RAYWHITE);

        // ----- botoes -----
        Rectangle botoes[11];
        const char* rotulos[11];
        int nb = 0;
        botoes[nb] = bManual; rotulos[nb++] = "Modo manual";
        botoes[nb] = bCarro;  rotulos[nb++] = "Modo carro";
        botoes[nb] = bLmenos; rotulos[nb++] = "-";
        botoes[nb] = bLmais;  rotulos[nb++] = "+";
        if (modo == 1) {
            botoes[nb] = bMmenos;   rotulos[nb++] = "-";
            botoes[nb] = bMmais;    rotulos[nb++] = "+";
            botoes[nb] = bVmenos;   rotulos[nb++] = "-";
            botoes[nb] = bVmais;    rotulos[nb++] = "+";
            botoes[nb] = bIniciar;  rotulos[nb++] = rodando ? "Pausar" : (terminou ? "De novo" : "Iniciar");
            botoes[nb] = bReinicia; rotulos[nb++] = "Reiniciar";
            botoes[nb] = bEscala;   rotulos[nb++] = ROT_ESCALA[idxEscala];
        }
        for (int i = 0; i < nb; i++) {
            Color cor = CheckCollisionPointRec(mouse, botoes[i]) ? Color{205, 225, 245, 255} : LIGHTGRAY;
            if ((i == 0 && modo == 0) || (i == 1 && modo == 1)) cor = SKYBLUE;
            DrawRectangleRec(botoes[i], cor);
            DrawRectangleLinesEx(botoes[i], 1, GRAY);
            int tw = MeasureText(rotulos[i], 18);
            DrawText(rotulos[i], (int)(botoes[i].x + (botoes[i].width - tw) / 2),
                     (int)(botoes[i].y + (botoes[i].height - 18) / 2), 18, DARKGRAY);
        }
        DrawText(TextFormat("Comprimento L: %.0f m", comprimento), 405, 29, 18, DARKGRAY);
        DrawText(TextFormat("S = %.1f m", vao), 650, 29, 18, DARKGRAY);

        // ----- legenda de cores -----
        DrawCircle(30, 82, 7, GREEN);   DrawText("OK", 44, 74, 16, DARKGRAY);
        DrawCircle(90, 82, 7, GOLD);    DrawText("Perto do limite", 104, 74, 16, DARKGRAY);
        DrawCircle(250, 82, 7, RED);    DrawText("Fora de 108 - 831", 264, 74, 16, DARKGRAY);
        DrawRectangle(440, 75, 14, 14, ORANGE); DrawText("Pilar recebendo carga do carro", 462, 74, 16, DARKGRAY);

        // ----- chao e tabuleiro -----
        DrawLineEx({PX0 - 40, Y_CHAO}, {PX1 + 40, Y_CHAO}, 2, DARKGRAY);
        DrawRectangle((int)(PX0 - 15), (int)Y_DECK, (int)(PX1 - PX0 + 30), 10, GRAY);

        // ----- zona de influencia do carro -----
        bool carroVisivel = (modo == 1) && !terminou && (rodando || posCarro > 0);
        if (carroVisivel) {
            float cx = PX0 + posCarro * escalaPx;
            float x0 = fmaxf(PX0 - 15, cx - vao * escalaPx);
            float x1 = fminf(PX1 + 15, cx + vao * escalaPx);
            DrawRectangle((int)x0, (int)(Y_DECK - 40), (int)(x1 - x0), 40, Fade(ORANGE, 0.12f));
        }

        // ----- pilares, estais e sensores -----
        for (int p = 0; p < NP; p++) {
            float x = PX0 + p * vao * escalaPx;
            float d1 = vao * escalaPx * 0.15f, d2 = vao * escalaPx * 0.30f;
            if (p > 0) {
                DrawLineEx({x, Y_TOPO + 5}, {x - d1, Y_DECK}, 1.5f, GRAY);
                DrawLineEx({x, Y_TOPO + 5}, {x - d2, Y_DECK}, 1.5f, GRAY);
            }
            if (p < NP - 1) {
                DrawLineEx({x, Y_TOPO + 5}, {x + d1, Y_DECK}, 1.5f, GRAY);
                DrawLineEx({x, Y_TOPO + 5}, {x + d2, Y_DECK}, 1.5f, GRAY);
            }
            Color corPilar = influencia[p] > 0 ? ORANGE : Color{150, 150, 150, 255};
            DrawRectangle((int)(x - 9), (int)Y_TOPO, 18, (int)(Y_CHAO - Y_TOPO), corPilar);
            DrawText(TextFormat("Viga 0%d", p + 1), (int)(x - 30), (int)(Y_CHAO + 10), 18, DARKGRAY);

            for (int s = 0; s < NS; s++) {
                float v = tensao[p][s];
                Color cor = GREEN;
                if (v < LIM_MIN || v > LIM_MAX) cor = RED;
                else if (v > LIM_MAX * 0.9f || v < LIM_MIN * 1.2f) cor = GOLD;
                if (modo == 0 && p == selP && s == selS) DrawCircleLines((int)x, (int)Y_SENSOR[s], 13, BLUE);
                DrawCircle((int)x, (int)Y_SENSOR[s], 8, cor);
                DrawText(TextFormat("S%d %.0f", s + 1, v), (int)(x + 14), (int)(Y_SENSOR[s] - 8), 16, DARKGRAY);
            }
        }

        // ----- carro -----
        if (modo == 1) {
            float cx;
            if (terminou) cx = PX1 + 45;
            else if (!rodando && posCarro <= 0) cx = PX0 - 45;
            else cx = PX0 + posCarro * escalaPx;
            DrawRectangleRounded({cx - 18, Y_DECK - 17, 36, 14}, 0.4f, 4, BLUE);
            DrawCircle((int)(cx - 10), (int)(Y_DECK - 2), 4, DARKGRAY);
            DrawCircle((int)(cx + 10), (int)(Y_DECK - 2), 4, DARKGRAY);
        }

        // ----- area de instrucoes / controles -----
        if (modo == 0) {
            DrawText("Clique num sensor, digite o valor e aperte ENTER (passa para o proximo).", 20, 490, 18, DARKGRAY);
            DrawText("Setas cima/baixo: +-10   |   ESC: cancela a edicao", 20, 515, 18, GRAY);
            if (selP >= 0) {
                bool pisca = ((int)(GetTime() * 2)) % 2 == 0;
                DrawText(TextFormat("Viga 0%d - S%d:  %s%s", selP + 1, selS + 1, entrada.c_str(), pisca ? "_" : ""),
                         20, 560, 24, BLUE);
                if (!msgErro.empty()) DrawText(msgErro.c_str(), 360, 563, 20, RED);
            }
        } else {
            DrawText(TextFormat("Tempo: %.1f s    Posicao: %.0f m de %.0f m    Velocidade da animacao: %s",
                                tempoSim, posCarro, comprimento, ROT_ESCALA[idxEscala]), 20, 490, 18, DARKGRAY);
            DrawText("ESPACO: iniciar/pausar", 20, 515, 18, GRAY);
            DrawText(TextFormat("%.0f kg", massa), 70, 567, 18, DARKGRAY);
            DrawText(TextFormat("%.0f km/h", velocidade), 340, 567, 18, DARKGRAY);
            DrawText("Massa", 20, 600, 16, GRAY);
            DrawText("Velocidade", 290, 600, 16, GRAY);
        }

        // ----- painel lateral -----
        DrawRectangle((int)PAINEL_X - 10, 0, LARGURA_TELA - (int)PAINEL_X + 10, ALTURA_TELA, Color{240, 240, 240, 255});
        if (pilaresAlerta == 0) DrawText("Ponte dentro dos limites", (int)PAINEL_X, 20, 18, DARKGREEN);
        else DrawText(TextFormat("ALERTA: %d pilar(es)", pilaresAlerta), (int)PAINEL_X, 20, 20, RED);

        for (int p = 0; p < NP; p++) {
            int y0 = 60 + p * 150;
            float media = (tensao[p][0] + tensao[p][1] + tensao[p][2]) / NS;
            bool fora = false;
            for (int s = 0; s < NS; s++)
                if (tensao[p][s] < LIM_MIN || tensao[p][s] > LIM_MAX) fora = true;

            DrawText(TextFormat("Viga 0%d", p + 1), (int)PAINEL_X, y0, 20, BLACK);
            DrawText(fora ? "ALERTA" : "OK", (int)PAINEL_X + 190, y0, 20, fora ? RED : DARKGREEN);
            DrawText(TextFormat("S1 %.0f  S2 %.0f  S3 %.0f", tensao[p][0], tensao[p][1], tensao[p][2]),
                     (int)PAINEL_X, y0 + 26, 16, DARKGRAY);
            DrawText(TextFormat("Media: %.1f", media), (int)PAINEL_X, y0 + 48, 18, DARKGRAY);

            // barra da media (escala 0 a 1000) com marcas dos limites
            float bw = 260.0f;
            float preenche = fminf(media, 1000.0f) / 1000.0f * bw;
            DrawRectangle((int)PAINEL_X, y0 + 74, (int)bw, 14, LIGHTGRAY);
            DrawRectangle((int)PAINEL_X, y0 + 74, (int)preenche, 14, fora ? RED : (media > LIM_MAX * 0.9f ? GOLD : GREEN));
            int xMin = (int)(PAINEL_X + LIM_MIN / 1000.0f * bw);
            int xMax = (int)(PAINEL_X + LIM_MAX / 1000.0f * bw);
            DrawLine(xMin, y0 + 70, xMin, y0 + 92, BLACK);
            DrawLine(xMax, y0 + 70, xMax, y0 + 92, BLACK);

            if (modo == 1) {
                float maior = fmaxf(pico[p][0], fmaxf(pico[p][1], pico[p][2]));
                DrawText(TextFormat("Pico na travessia: %.0f", maior), (int)PAINEL_X, y0 + 100, 16,
                         maior > LIM_MAX ? RED : GRAY);
            }
        }

        EndDrawing();
    }

    CloseWindow();
    return 0;
}
